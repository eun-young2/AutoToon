// 캘린더 페이지 판넬에서
// 아이콘 색상 추출하는 팔레트 기능을
// 앱 실행시에
// 사전 로드하기 위한 로직입니다.( 렉 줄일려는 의도)


// 고정된 stamps asset 목록
const List<String> kSentimentStampAssets = [
  'assets/stamps/stamp_happy.gif',
  'assets/stamps/stamp_angry.gif',
  'assets/stamps/stamp_peace.gif',
  'assets/stamps/stamp_sad.gif',
  'assets/stamps/stamp_surprise.gif',
];